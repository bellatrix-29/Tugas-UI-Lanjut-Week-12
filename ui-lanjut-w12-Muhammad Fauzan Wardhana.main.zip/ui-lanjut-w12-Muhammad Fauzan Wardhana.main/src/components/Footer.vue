<template>
  <footer class="footer">
    <small>2025 My Vue App</small>
  </footer>
</template>