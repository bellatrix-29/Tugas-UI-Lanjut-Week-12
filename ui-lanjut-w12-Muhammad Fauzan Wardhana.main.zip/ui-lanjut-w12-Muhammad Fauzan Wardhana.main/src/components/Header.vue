<template>
  <header class="header">
    <h1>Ardhan List</h1>
    <nav>
      <RouterLink to="/" class="nav-link">Todo</RouterLink>
      <RouterLink to="/edit" class="nav-link">Edit</RouterLink>
      <RouterLink to="/completed" class="nav-link">Completed</RouterLink>
    </nav>
  </header>
</template>