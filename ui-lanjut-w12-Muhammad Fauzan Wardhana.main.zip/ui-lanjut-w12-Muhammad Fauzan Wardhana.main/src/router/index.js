import { createRouter, createWebHistory } from 'vue-router'
import TodoView from '../views/Todo.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: TodoView
    },
    {
      path: '/edit/:id',
      name: 'edit',
      component: () => import('../views/EditTodo.vue')
    },
    // --- TAMBAHAN BARU ---
    {
      path: '/completed',
      name: 'completed',
      // Pastikan file Completed.vue ada di folder views
      component: () => import('../views/Completed.vue') 
    }
    // ---------------------
  ]
})

export default router