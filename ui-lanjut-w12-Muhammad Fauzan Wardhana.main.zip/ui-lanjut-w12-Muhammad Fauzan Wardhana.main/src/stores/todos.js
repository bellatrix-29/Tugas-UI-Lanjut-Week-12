import { defineStore } from 'pinia'

export const useTodos = defineStore('todos', {
  state: () => ({
    todos: [],
    nextId: 1, // Asumsi kamu punya counter ID
  }),
  getters: {
    pendingTodos: (state) => state.todos.filter((todo) => !todo.isCompleted),
    completedTodos: (state) => state.todos.filter((todo) => todo.isCompleted),
    
    // --- TAMBAHKAN GETTER INI ---
    getTodoById: (state) => {
      return (id) => state.todos.find((todo) => todo.id === id)
    }
    // ----------------------------
  },
  actions: {
    addTodo(text) {
      this.todos.push({ id: this.nextId++, text, isCompleted: false })
    },
    deleteTodo(id) {
      this.todos = this.todos.filter((todo) => todo.id !== id)
    },
    // Pastikan kamu punya action untuk update teks
    updateTodoContent(id, newText) {
      const todo = this.todos.find(t => t.id === id)
      if (todo) {
        todo.text = newText
      }
    },
    // Ini action yang sudah ada di kodemu (untuk checklist)
    updateTodo(updatedTodo) {
      const index = this.todos.findIndex((t) => t.id === updatedTodo.id)
      if (index !== -1) {
        this.todos[index] = updatedTodo
      }
    },
  },
})