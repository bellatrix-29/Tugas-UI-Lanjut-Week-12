<template>
  <div style="padding: 20px;">
    <h3>To-Do ⏳</h3>
    
    <!-- Form Tambah Todo -->
    <form @submit.prevent="addTodoWrapper">
      <input 
        v-model="todo.text" 
        type="text" 
        placeholder="Input tugas baru..." 
        style="padding: 8px; margin-right: 5px;"
      />
      <button 
        :disabled="!todo.text" 
        type="submit" 
        style="cursor: pointer;"
      >
        Add
      </button>
    </form>
    
    <div style="margin-top: 20px;">
      <ul>
        <li v-for="item in pendingTodos" :key="item.id" style="margin: 10px 0; display: flex; align-items: center; gap: 10px;">
          
          <!-- Tampilkan Teks Biasa -->
          <span style="flex-grow: 1;">{{ item.text }}</span>
          
          <!-- Tombol Selesai: Arahkan ke halaman Edit dulu -->
          <button 
            @click="goToEdit(item.id)" 
            style="cursor: pointer;"
            title="Cek & Edit di Halaman Lain"
          >
            ✅
          </button>

          <!-- Tombol Edit: Pindah ke halaman Edit -->
          <button 
            @click="goToEdit(item.id)" 
            style="cursor: pointer;"
            title="Pindah ke Halaman Edit"
          >
            ✏️ Edit
          </button>

          <!-- Tombol Hapus -->
          <button 
            @click="deleteTodo(item.id)" 
            style="cursor: pointer;"
            title="Hapus"
          >
            ❌
          </button>

        </li>
      </ul>

      <p v-if="pendingTodos.length === 0" style="color: gray; font-style: italic;">
        Tidak ada tugas yang tertunda.
      </p>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia';
import { useTodos } from '../stores/todos'; 

export default {
  data() {
    return {
      todo: { text: '', id: null }
    }
  },
  computed: {
    ...mapState(useTodos, ['pendingTodos'])
  },
  methods: {
    ...mapActions(useTodos, ['addTodo', 'deleteTodo']),
    
    addTodoWrapper() {
        if(this.todo.text) {
            this.addTodo(this.todo.text);
            this.todo.text = ''; 
        }
    },

    // Fungsi Routing: Pindah ke URL /edit/:id
    goToEdit(id) {
        this.$router.push(`/edit/${id}`);
    }
  }
}
</script>