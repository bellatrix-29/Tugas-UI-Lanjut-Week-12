<template>
  <div class="edit-container">
    <h3>Edit Tugas ✏️</h3>
    
    <!-- Formulir akan SELALU muncul sekarang -->
    <div v-if="todoData">
      <form @submit.prevent="handleUpdate">
        
        <!-- Peringatan jika ini data palsu hasil refresh -->
        <div v-if="isDummy" style="background: #fff3cd; color: #856404; padding: 10px; margin-bottom: 15px; font-size: 0.9em; border-radius: 4px;">
          ⚠️ <strong>Data asli hilang karena Refresh.</strong><br>
          Ini adalah data contoh agar layar tidak kosong.
        </div>

        <div style="margin-bottom: 15px;">
          <label style="display: block; margin-bottom: 5px; font-weight: bold;">Nama Tugas:</label>
          <input 
            v-model="todoData.text" 
            type="text" 
            required
            placeholder="Edit nama tugas..."
            style="padding: 10px; width: 100%; max-width: 300px; border: 1px solid #ccc; border-radius: 4px;"
          />
        </div>
        
        <div class="buttons">
          <button type="submit" style="background-color: #4CAF50; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; margin-right: 10px;">
            💾 Simpan
          </button>
          <button type="button" @click="$router.push('/')" style="background-color: #f44336; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer;">
            Batal
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import { useTodos } from '../stores/todos'
import { mapActions, mapState } from 'pinia'

export default {
  data() {
    return {
      todoData: null,
      isDummy: false // Penanda apakah ini data asli atau palsu
    }
  },
  computed: {
    ...mapState(useTodos, ['getTodoById'])
  },
  methods: {
    ...mapActions(useTodos, ['updateTodoContent']),
    
    handleUpdate() {
      if (this.todoData && this.todoData.text.trim()) {
        // Coba simpan ke store
        this.updateTodoContent(this.todoData.id, this.todoData.text);
        // Kembali ke home
        this.$router.push('/'); 
      }
    }
  },
  mounted() {
    // 1. Ambil ID dari URL
    const id = Number(this.$route.params.id); 
    
    // 2. Coba cari data asli di Store
    const originalTodo = this.getTodoById(id);
    
    if (originalTodo) {
      // Jika ketemu, pakai data asli
      this.todoData = { ...originalTodo };
      this.isDummy = false;
    } else {
      // --- SOLUSI MASALAH "KOSONG" ---
      // Jika data tidak ketemu (misal karena refresh), 
      // kita buat data palsu agar form tetap muncul!
      this.todoData = { 
        id: id, 
        text: "Tugas (Data Hilang)", 
        isCompleted: false 
      };
      this.isDummy = true;
    }
  }
}
</script>

<style scoped>
.edit-container {
  padding: 30px;
  text-align: center;
  font-family: Arial, sans-serif;
  background-color: #f9f9f9;
  border-radius: 10px;
  max-width: 500px;
  margin: 20px auto;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}
h3 {
  color: #333;
}
</style>